# ThanhCAM — Xoan oc G2/G3: bo K, bo X Y lap o vong kin
# Nguon: https://thanhcam.com/huong-dan/  |  Thu tren NX 12.0.2 Post Builder, post phay 3 truc Generic.
# Cach dung: Tao 2 Custom Command: is_closed_xy_helix (phan 1) va init_helix (phan 2). Xem bai huong dan de biet cho goi.
# Kiem tra lai tren may cua ban truoc khi chay that.

# ===== Phan 1: PB_CMD_is_closed_xy_helix =====
# A helix turn that ends where it started (same X/Y, XY plane, absolute) needs no X/Y.
   # Works with or without pitch output (K).
   global mom_pos_arc_plane mom_output_mode
   global mom_pos mom_prev_pos

   if { ![info exists mom_pos_arc_plane] || $mom_pos_arc_plane ne "XY" ||
        ![info exists mom_output_mode] || $mom_output_mode ne "ABSOLUTE" } {
      return 0
   }
   foreach axis {0 1} {
      if { ![info exists mom_pos($axis)] || ![info exists mom_prev_pos($axis)] } {
         return 0
      }
      # Numerical closure only; do not round a small genuine move to a circle.
      if { abs($mom_pos($axis) - $mom_prev_pos($axis)) > 1.0e-9 } {
         return 0
      }
   }
   return 1
# ===== Phan 2: PB_CMD_init_helix =====
uplevel #0 {
# 
# This ommand will be executed automatically at the start of program and
# anytime it is loaded as a slave post of a linked post.
#
# This procedure can be used to enable your post to output helix.
# You can choose from the following options to format the circle
# block template to output the helix parameters.
#

   #set mom_sys_helix_pitch_type    "rise_radian"
   set mom_sys_helix_pitch_type "none"
#
# The default setting for mom_sys_helix_pitch_type is "rise_radian".
# This is the most common.  Other choices are:
#
#    "rise_radian"              Measures the rise over one radian.
#    "rise_revolution"          Measures the rise over 360 degrees.
#    "none"                     Will suppress the output of pitch.
#    "other"                    Allows you to calculate the pitch
#                               using your own formula.
#
# This custom command uses the block template circular_move to output
# the helix block.  If your post uses a block template with a different
# name, you must edit the line that outputs the helix block.

#
#  The following variable deines the output mode for helical records.
#
#  FULL_CIRCLE  -- This mode will output a helix record for each 360
#                  degrees of the helix.
#  QUADRANT  --    This mode will output a helix record for each 90
#                  degrees of the helix.
#  LINEAR  --      This mode will output the entire helix as linear gotos.
#  END_POINT --    This mode will assume the control can define an entire
#                  helix in a single block.

   set mom_kin_helical_arc_output_mode FULL_CIRCLE

   MOM_reload_kinematics


#=============================================================
proc MOM_helix_move { } {
#=============================================================
   global mom_pos_arc_plane
   global mom_sys_cir_vector
   global mom_sys_helix_pitch_type
   global mom_helix_pitch
   global mom_prev_pos mom_pos_arc_center
   global PI


   switch $mom_pos_arc_plane {
      XY { MOM_suppress once K ; set cir_index 2 }
      YZ { MOM_suppress once I ; set cir_index 0 }
      ZX { MOM_suppress once J ; set cir_index 1 }
   }

   switch $mom_sys_helix_pitch_type {
      none { }
      rise_revolution { set pitch $mom_helix_pitch }
      rise_radian { set pitch [expr $mom_helix_pitch / ($PI * 2.0)]}
      other {
#
#    Place your custom helix pitch code here
#
      }
      default { set mom_sys_helix_pitch_type "none" }
   }

   # Only a closed XY helix in absolute mode can omit both endpoint words.
   # Partial arcs (including the final half turn) retain the original forcing.
   if { [PB_CMD_is_closed_xy_helix] } {
      MOM_force once Z
      MOM_suppress once X Y
   } else {
      MOM_force once X Y Z
   }

   if { [string compare "none" $mom_sys_helix_pitch_type] } {
      MOM_force once I J K

     #<08-01-06 gsl>
      switch $mom_sys_cir_vector {
         "Vector - Arc Center to Start" {
            set mom_prev_pos($cir_index) $pitch
            set mom_pos_arc_center($cir_index) 0.0
         }
         "Vector - Arc Start to Center" -
         "Unsigned Vector - Arc Start to Center" {
            set mom_prev_pos($cir_index) 0.0
            set mom_pos_arc_center($cir_index) $pitch
         }
         "Vector - Absolute Arc Center" {
            set mom_pos_arc_center($cir_index) $pitch
         }
      }
   }

#
# You may need to edit this line if you output more than one block
# or if you have changed the name of your circular_move block template
#
   MOM_do_template circular_move
}

} ;# uplevel
